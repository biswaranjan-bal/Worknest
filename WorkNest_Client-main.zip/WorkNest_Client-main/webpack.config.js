// webpack.config.js

module.exports = {
    // Other webpack configurations...
    module: {
      rules: [
        {
          test: /\.css$/,
          use: ['style-loader', 'css-loader']
        }
      ]
    }
  };
  